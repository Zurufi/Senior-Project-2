﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Pediatrics.Data;
using Pediatrics.Models;
using static System.Collections.Specialized.BitVector32;


// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

public class AccountController : Controller
{
    private readonly ApplicationDbContext _context;


    public AccountController(ApplicationDbContext context)
    {
        _context = context;

    }

    [HttpGet]
    public ActionResult Login()
    {
        return View();
    }

    //Handle Logging in 
    [HttpPost]
    [ValidateAntiForgeryToken]
    public ActionResult Login(User user)
    {
       //get user from database
        var validUser = _context.Users.FirstOrDefault(u => u.email == user.email && u.Password == user.Password && u.Role == user.Role);

        //if user is found
        if (validUser != null)
        {
            //set id and role in session variables
            HttpContext.Session.SetInt32("UserId", validUser.id);
            HttpContext.Session.SetString("Role", validUser.Role);
            switch (validUser.Role)
            {
                //depending on role send to appropriate view
                case "Patient":
                    return RedirectToAction("PatientHome");
                case "Doctor":
                    return RedirectToAction("DoctorHome");
                case "Staff":
                    return RedirectToAction("StaffHome");
                default:
                    return RedirectToAction("Index");
            }
        }

        ViewBag.Message = "Invalid credentials";
        Console.WriteLine("Invalid credentials");
        return View();
    }
    public ActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Login");
    }

    [HttpGet]
    public ActionResult Register()
    {
        return View();
    }
    //Handle creating new account
    [HttpPost]
    [ValidateAntiForgeryToken]
    public ActionResult Register(User user)
    {
       //add to database and save
        _context.Users.Add(user);
        _context.SaveChanges();
        return RedirectToAction("Login");

    }

    // GET: /<controller>/
    public IActionResult Index()
    {
        var patient = _context.Users.ToList();

        return View(patient);
    }
    //Home page for each role
    public ActionResult PatientHome()
    {
        var patient = _context.Users.Where(u => u.id == HttpContext.Session.GetInt32("UserId"));
        return View(patient);
    }

    public ActionResult DoctorHome()
    {
        var availability = _context.Availability.ToList();
        return View(availability);
    }


    public ActionResult StaffHome()
    {
        var schedule = _context.Schedule.ToList();

        return View(schedule);
    }
    //Create availability from Doctor Home Page
    [HttpGet]
    [Route("/Account/CreateAvailability")]
    public ActionResult CreateAvailability()
    {

        return View();

    }
    [HttpPost]
    [Route("/Account/CreateAvailability")]
    public ActionResult CreateAvailability(Availability availability)
    {
        Console.WriteLine("HEREEEEE");
        _context.Availability.Add(availability);
        _context.SaveChanges();
        return RedirectToAction("CreateAvailability");

    }
    //Create Schedule from staff Home Page
    [HttpGet]
    [Route("/Account/CreateSchedule")]
    public ActionResult CreateSchedule()
    {

        return View();

    }
    [HttpPost]
    [Route("/Account/CreateSchedule")]
    public ActionResult CreateSchedule(Schedule schedule)
    {

        _context.Schedule.Add(schedule);
        _context.SaveChanges();
        return RedirectToAction("CreateSchedule");

    }
}