﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Pediatrics.Data;

namespace Pediatrics.Models
{
    public class AppointmentContext : ApplicationDbContext
    {
        public AppointmentContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
        public DbSet<Appointment> Appointments{ get; set; }
    }

    public class Appointment
    {
        [Key]
        public int id { get; set; }
        public int patient_id { get; set; }
        public int doctor_id { get; set; }
        public DateTime time { get; set; }
    }
}


