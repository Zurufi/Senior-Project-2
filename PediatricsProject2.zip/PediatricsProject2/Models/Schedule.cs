﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Pediatrics.Data;

namespace Pediatrics.Models
{
    public class ScheduleContext : ApplicationDbContext
    {
        public ScheduleContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
        public DbSet<Appointment> Schedule { get; set; }
    }

    public class Schedule
    {
        [Key]
        public int id { get; set; }
        public int doctor_id { get; set; }
        public TimeOnly start_time { get; set; }
        public TimeOnly end_time { get; set; }
        public string day { get; set; }

    }
}