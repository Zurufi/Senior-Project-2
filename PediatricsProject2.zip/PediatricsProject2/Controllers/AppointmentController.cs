﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Pediatrics.Data;
using Pediatrics.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Pediatrics.Controllers
{
    public class AppointmentController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AppointmentController(ApplicationDbContext context)
        {
            _context = context;

        }

        [HttpGet]
        [Route("Appointment/Create")]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [Route("Appointment/Create")]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Appointment appointment)
        {
            
            
            _context.Appointments.Add(appointment);
            _context.SaveChanges();
            return RedirectToAction("Index");

        }
        // GET: /<controller>/
        public IActionResult Index()
        {
            //if user is logged in 
            if (HttpContext.Session.GetInt32("UserId") != null)
            {
                //get role
                String role = HttpContext.Session.GetString("Role");

                if (role == "Staff")
                {
                    //get all appointments
                    var appointments = _context.Appointments.ToList();
                    return View(appointments);
                }
                else if (role == "Doctor")
                {
                    //get doctor's appointments
                    var appointments = _context.Appointments.Where(a => a.doctor_id == HttpContext.Session.GetInt32("UserId")).ToList();
                    return View(appointments);
                }

                else
                {
                    //get patient appointments
                    var appointments = _context.Appointments.Where(a => a.patient_id == HttpContext.Session.GetInt32("UserId")).ToList();
                    return View(appointments);
                }
            }
            return RedirectToAction("Login", "Account");

            
        }
    }
}

