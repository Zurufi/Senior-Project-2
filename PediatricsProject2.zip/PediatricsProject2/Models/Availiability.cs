﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Pediatrics.Data;

namespace Pediatrics.Models
{
    public class AvailabilityContext : ApplicationDbContext
    {
        public AvailabilityContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
        public DbSet<Appointment> Availability { get; set; }
    }

    public class Availability
    {
        [Key]
        public int id { get; set; }
        public int doctor_id { get; set; }
        public TimeOnly start_time { get; set; }
        public TimeOnly end_time { get; set; }
        public string day { get; set; }

    }
}