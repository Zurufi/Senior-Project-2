﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Pediatrics.Data;
namespace Pediatrics.Models
{
    //Model Representing Users of the website 
    public class User
    {
       
           public class UserContext : ApplicationDbContext
        {
            public UserContext(DbContextOptions<ApplicationDbContext> options) : base(options)
            {
            }
            public DbSet<User> Users { get; set; }
        }

        [Key]
        public int id { get; set; }
        [Required]
        public required string email { get; set; }
        [Required]
        public required string name { get; set; }
        [Required]
        public required string Password { get; set; }
        [Required]
        public required string Role { get; set; }


        //? means can be null 
        public string? phone_number { get; set; }

      
        public string? address { get; set; }

     
        public string? insurance_provider { get; set; }

       
        public string? payment_type { get; set; }

       
        public string? payment_info { get; set; }

        [DataType(DataType.Date)]
        public DateTime birth_date { get; set; }

    }

}


